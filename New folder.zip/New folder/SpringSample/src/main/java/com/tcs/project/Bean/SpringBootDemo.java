package com.tcs.project.Bean;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SpringBootDemo {

	@Autowired
	private SampleDao sampledao;
	public static void main(String[] args) {
		
		SpringApplication.run(SpringBootDemo.class, args);
	}
@ResponseBody
@RequestMapping(value = "/getcustomer" , method = RequestMethod.POST)
public CustomerData getCustomer(@RequestBody String custid)
{
	String id =null;
	JSONParser parser = new JSONParser();
	JSONObject object = null;
	try
	{
		object = (JSONObject) parser.parse(custid);
		id = (String) object.get("id");
	}
	catch (Exception e) {
		
	}
	CustomerData customer = sampledao.getCustomer(id);
	return customer;
}
}
