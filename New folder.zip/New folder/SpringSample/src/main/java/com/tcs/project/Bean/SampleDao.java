package com.tcs.project.Bean;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
public class SampleDao {
	@Autowired
	@PersistenceContext
	private EntityManager entitymanager;
	
	public CustomerData getCustomer(String id)
	{
		CustomerData customer=null;
		customer=(CustomerData) this.entitymanager.createQuery("from CustomerData where custid=:id").setParameter("id",id).getSingleResult();
		return customer;
	}

}
