package btg.disp.util;

import org.json.JSONException;
import org.json.JSONObject;

public class RequestHelper 
{
	public String getRequestBody(String reqField, String payLoad)
	{
		String result="";
		try
		{
			JSONObject jsonObject = new JSONObject(payLoad);
			result = (String) jsonObject.getString(reqField);
		}
		catch (JSONException e)
		{
			e.printStackTrace();
		}
		return result;
	}
}
