package btg.disp.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetUI 
{
	public String getLogin(String userUrl, String userParam,String contType)
	{
		String result="";
		try
		{
			URL obj = new URL(userUrl);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("USer-Agent", "Mozilla/5.0");
			con.setRequestProperty("content-type", contType);
			//For POST only - START
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(userParam.getBytes());
			os.flush();
			os.close();
			//For POST only - END
			
			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code ::" + responseCode);
			
			if(responseCode == HttpURLConnection.HTTP_OK)
			{
				//success
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
				StringBuffer res1 = new StringBuffer();
				while((inputLine = in.readLine())!= null)
				{
					res1.append(inputLine);
				}
				
				result=res1.toString();
				in.close();
				// print result
				//System.out.println(res1.toString());
			}
			else
			{
				System.out.println("POST request not worked");
			}
		}
		catch(Exception e)
		{
			System.out.println("Error : " + e.getMessage());
		}
		
		return result;
	}
}
