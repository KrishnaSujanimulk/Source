package bean;

public interface CustomerDao {
	public void addCustomer(String CustId, String CustName, String age, String Address, String contactNumber,
			String country);
}
