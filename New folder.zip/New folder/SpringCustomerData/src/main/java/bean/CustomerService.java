package bean;

public interface CustomerService {
	public void addCustomer(String CustId, String CustName, String age, String Address, String contactNumber,
			String country);
}
