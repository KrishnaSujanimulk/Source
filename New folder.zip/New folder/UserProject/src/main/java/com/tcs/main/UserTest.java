package com.tcs.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserTest {

	public static void main(String[] args) {
		SpringApplication.run(UserTest.class, args);
	}

}
