package com.tcs.test;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sampletest {

	static Logger logger = Logger.getLogger(Sampletest.class.getName());
	public static void main(String[] args) {
		logger.info("Before triggering run method in main method");
		logger.debug("Before triggering run method in main method");
		logger.warn("Before triggering run method in main method");
		logger.error("Before triggering run method in main method");
		logger.fatal("Before triggering run method in main method");
		SpringApplication.run(Sampletest.class, args);
	}

}
