package com.tcs.test.Dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.tcs.test.bean.Customerbean;


@Repository
public class CustomerDaoImpl implements CustomerDao
{
	private static final Map<String,Customerbean> customermap = new HashMap<String,Customerbean>();
	public void addCustomer(String customerId, String customerName, String age, String address, String city,
			String contactNumber, String country) {
		Customerbean bean = new Customerbean(customerId, customerName, age, address, city, contactNumber, country);
		customermap.put(customerId, bean);
}
	public static Collection getAllcustomers() 
	{
		return customermap.values();
	}
	public static void deleteCustomer(String removeId) 
	{
		customermap.remove(removeId);	
	}
	public static void updateCustomer(String updateId, String customerName, String age, String address, String city,
			String contactNumber, String country) {
		Customerbean bean = new Customerbean(updateId, customerName, age, address, city, contactNumber, country);
		customermap.put(updateId, bean);
		
	}
	public static String retrieveCustomer(String retrieveId) 
	{
		return customermap.get(retrieveId).toString();	
	}
	
}
