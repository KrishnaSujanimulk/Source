package com.tcs.test.token;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class Tokentest {
	@Autowired
	private TokenDemo tokendemo;
	String strValue = null;

	public static void main(String[] args) 
	{
		SpringApplication.run(Tokentest.class, args);
	}
	@ResponseBody
	@RequestMapping(value = "/encryptname" , method = RequestMethod.POST)
	public String encryptName(@RequestBody String user_name)
	{
		strValue = tokendemo.encryptMessage(user_name);
		return strValue;
	}
	
	@ResponseBody
	@RequestMapping(value = "/decryptname" , method = RequestMethod.POST)
	public List decryptName()
	{
		List list =tokendemo.decryptMessage(strValue);
		return list;
	}
}
