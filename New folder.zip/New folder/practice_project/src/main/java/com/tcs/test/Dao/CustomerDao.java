package com.tcs.test.Dao;

public interface CustomerDao 
{
	public void addCustomer(String customerId, String customerName, String age, String address, String city,
			String contactNumber, String country);
}
