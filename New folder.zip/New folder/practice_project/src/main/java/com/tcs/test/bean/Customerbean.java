package com.tcs.test.bean;

public class Customerbean 
{
	private String customerId;
	private String customerName;
	private String age;
	private String address;
	private String city;
	private String contactNumber;
	public Customerbean(String customerId, String customerName, String age, String address, String city,
			String contactNumber, String country) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.age = age;
		this.address = address;
		this.city = city;
		this.contactNumber = contactNumber;
		this.country = country;
	}
	private String country;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "Customerbean [customerId=" + customerId + ", customerName=" + customerName + ", age=" + age
				+ ", address=" + address + ", city=" + city + ", contactNumber=" + contactNumber + ", country="
				+ country + "]";
	}

}
