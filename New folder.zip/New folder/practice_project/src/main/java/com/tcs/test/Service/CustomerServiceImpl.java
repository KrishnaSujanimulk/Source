package com.tcs.test.Service;

import com.tcs.test.Dao.CustomerDaoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService
{
	@Autowired
	private CustomerDaoImpl customerdaoimpl;
	@Override
	public void addCustomer(String customerId, String customerName, String age, String address, String city,
			String contactNumber, String country) {
		customerdaoimpl.addCustomer(customerId, customerName, age, address, city, contactNumber, country);
		
	}
	
}
