package com.tcs.test.Controller;

import java.util.Collection;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.tcs.test.Dao.CustomerDaoImpl;

import com.tcs.test.Service.CustomerServiceImpl;



@SpringBootApplication
@RestController
public class CustomerDemo {

@Autowired
private CustomerServiceImpl customerserviceimpl;
	public static void main(String[] args) {
		SpringApplication.run(CustomerDemo.class, args);

	}

	@ResponseBody
	@RequestMapping(value = "/addcustomer", method = RequestMethod.POST)
	public void addCustomer(@RequestBody String customer) {
		JSONParser parser = new JSONParser();
		org.json.simple.JSONObject object = null;
		try {
			object = (org.json.simple.JSONObject) parser.parse(customer);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String customerId = (String) object.get("customer_id");
		String customerName = (String) object.get("customer_name");
		String age = (String) object.get("age");
		String address = (String) object.get("address");
		String city = (String) object.get("city");
		String contactNumber = (String) object.get("contact_number");
		String country = (String) object.get("country");
		customerserviceimpl.addCustomer(customerId,customerName,age,address,city,contactNumber,country);
	}
@ResponseBody
@RequestMapping(value = "/getAllcustomers", method = RequestMethod.GET)	
public Collection getAllcustomers()
{
	return CustomerDaoImpl.getAllcustomers();
	
}
@ResponseBody
@RequestMapping(value = "/deletecustomer", method = RequestMethod.POST)
public void deleteCustomer(@RequestBody String id)
{
	JSONParser parser = new JSONParser();
	org.json.simple.JSONObject object = null;
	try {
		object = (org.json.simple.JSONObject) parser.parse(id);
	} catch (ParseException e) {
		e.printStackTrace();
	}
String removeId = (String) object.get("customer_id");
CustomerDaoImpl.deleteCustomer(removeId);
}
@ResponseBody
@RequestMapping(value = "/updatecustomer", method = RequestMethod.POST)
public void updateCustomer(@RequestBody String id) {
	JSONParser parser = new JSONParser();
	org.json.simple.JSONObject object = null;
	try {
		object = (org.json.simple.JSONObject) parser.parse(id);
	} catch (ParseException e) {
		e.printStackTrace();
	}
	String updateId = (String) object.get("customer_id");
	String customerName = (String) object.get("customer_name");
	String age = (String) object.get("age");
	String address = (String) object.get("address");
	String city = (String) object.get("city");
	String contactNumber = (String) object.get("contact_number");
	String country = (String) object.get("country");
	CustomerDaoImpl.updateCustomer(updateId,customerName,age,address,city,contactNumber,country);
}
@ResponseBody
@RequestMapping(value = "/retrievecustomer", method = RequestMethod.POST)
public String retrieveCustomer(@RequestBody String id)
{
	JSONParser parser = new JSONParser();
	org.json.simple.JSONObject object = null;
	try {
		object = (org.json.simple.JSONObject) parser.parse(id);
	} catch (ParseException e) {
		e.printStackTrace();
	}
String retrieveId = (String) object.get("customer_id");
return CustomerDaoImpl.retrieveCustomer(retrieveId).toString();
}
}